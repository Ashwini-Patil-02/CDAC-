
#include <iostream>
#include <windows.h>
#include <conio.h>
#include <ctime>

using namespace std;

// Console dimensions
const int WIDTH = 50;
const int HEIGHT = 20;

// Ball properties
int ballX = WIDTH / 2, ballY = HEIGHT / 2; // Initial position
int ballDirX = 1, ballDirY = 1;           // Initial direction
int score = 0;                            // Score counter

// Utility function to move the cursor to a specific position in the console
void gotoxy(int x, int y) {
    COORD coord;
    coord.X = x;
    coord.Y = y;
    SetConsoleCursorPosition(GetStdHandle(STD_OUTPUT_HANDLE), coord);
}

// Function to set the console text and background color
void setColor(int textColor, int backgroundColor) {
    int color = textColor + (backgroundColor * 16);
    SetConsoleTextAttribute(GetStdHandle(STD_OUTPUT_HANDLE), color);
}

// Function to display the start screen with instructions
void displayStartScreen() {
    system("cls"); // Clear console
    setColor(15, 0); // White text on black background
    gotoxy(WIDTH / 4, HEIGHT / 2 - 2);
    cout << "Welcome to the Bouncing Ball Game!";
    gotoxy(WIDTH / 4, HEIGHT / 2);
    cout << "Instructions:";
    gotoxy(WIDTH / 4, HEIGHT / 2 + 1);
    cout << "1. Watch the ball bounce inside the box.";
    gotoxy(WIDTH / 4, HEIGHT / 2 + 2);
    cout << "2. Your score increases when the ball bounces off walls.";
    gotoxy(WIDTH / 4, HEIGHT / 2 + 3);
    cout << "3. Press 'q' to quit the game.";
    gotoxy(WIDTH / 4, HEIGHT / 2 + 5);
    cout << "Press any key to start the game...";
    _getch(); // Wait for a key press to start the game
}

// Function to draw the boundary with a background color
void drawBoundary() {
    setColor(0, 11); // Light cyan background for the boundary (you can change the color here)
    for (int x = 0; x <= WIDTH; x++) {
        gotoxy(x, 0);
        cout << " "; // Top boundary
        gotoxy(x, HEIGHT);
        cout << " "; // Bottom boundary
    }
    for (int y = 0; y <= HEIGHT; y++) {
        gotoxy(0, y);
        cout << " "; // Left boundary
        gotoxy(WIDTH, y);
        cout << " "; // Right boundary
    }
}

// Function to display the score
void displayScore() {
    setColor(14, 0); // Yellow text on black background
    gotoxy(WIDTH + 2, 1);
    cout << "Score: " << score;
}

// Function to update and move the ball
void moveBall() {
    // Erase the ball's previous position
    gotoxy(ballX, ballY);
    cout << " ";

    // Update ball position
    ballX += ballDirX;
    ballY += ballDirY;

    // Check for collisions with boundaries
    if (ballX <= 1 || ballX >= WIDTH - 1) {
        ballDirX *= -1; // Reverse horizontal direction
        score++; // Increase score
        setColor(rand() % 15 + 1, 11); // Change ball color randomly
    }
    if (ballY <= 1 || ballY >= HEIGHT - 1) {
        ballDirY *= -1; // Reverse vertical direction
        score++; // Increase score
        setColor(rand() % 15 + 1, 11); // Change ball color randomly
    }

    // Draw the ball in its new position
    gotoxy(ballX, ballY);
    cout << "O";

    // Display the updated score
    displayScore();
}

int main() {
    // Seed the random number generator for colors
    srand(time(0));

    // Hide the cursor for better visuals
    CONSOLE_CURSOR_INFO cursorInfo;
    cursorInfo.bVisible = false;
    cursorInfo.dwSize = 1;
    SetConsoleCursorInfo(GetStdHandle(STD_OUTPUT_HANDLE), &cursorInfo);

    // Display the start screen
    displayStartScreen();

    // Draw the boundary and initial score
    system("cls"); // Clear the console
    drawBoundary();
    displayScore();

    // Game loop
    while (true) {
        moveBall();
        Sleep(50); // Adjust speed of the ball

        // Exit condition (press 'q' to quit)
        if (_kbhit() && _getch() == 'q') {
            break;
        }
    }

    // Restore cursor visibility before exiting
    cursorInfo.bVisible = true;
    SetConsoleCursorInfo(GetStdHandle(STD_OUTPUT_HANDLE), &cursorInfo);

    // Goodbye message
    system("cls");
    setColor(15, 0); // Reset to white text on black background
    gotoxy(WIDTH / 4, HEIGHT / 2);
    cout << "Game Over! Your final score is: " << score;
    gotoxy(WIDTH / 4, HEIGHT / 2 + 2);
    cout << "Thank you for playing!";
    
    // Add delay so the user can see the final message
    Sleep(3000); // Wait for 3 seconds before exiting

    gotoxy(0, HEIGHT + 2);
    return 0;
}
