package com.blogs.dao;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;

import com.blogs.entities.Category;

public interface CategoryDao extends JpaRepository<Category, Long> {
//to fetch catgeory + posts in a single join query
	@Query("select c from Category c left join fetch c.posts where c.id=:id")
	Category getCategoryAndPostDetails(Long id);

}
