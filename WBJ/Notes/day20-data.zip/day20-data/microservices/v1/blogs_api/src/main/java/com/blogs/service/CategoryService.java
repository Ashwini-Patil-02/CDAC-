package com.blogs.service;

import java.util.List;

import com.blogs.dto.CategoryDTO;
import com.blogs.dto.CategoryPostDTO;
import com.blogs.entities.Category;

public interface CategoryService {
	List<CategoryDTO> getCategories();
	String addNewCategory(CategoryDTO newCategory);
	String deleteCategory(Long categoryId);
	CategoryDTO getCategory(Long categoryId);
	String updateCategory(Long categoryId, Category category);
	CategoryPostDTO getCategoryAndPosts(Long categoryId);
}
