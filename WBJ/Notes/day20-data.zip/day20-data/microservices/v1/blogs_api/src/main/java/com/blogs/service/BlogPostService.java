package com.blogs.service;

import com.blogs.dto.ApiResponse;
import com.blogs.dto.BlogPostReqDTO;

public interface BlogPostService {
ApiResponse postNewBlog(BlogPostReqDTO requestDTO);
}
