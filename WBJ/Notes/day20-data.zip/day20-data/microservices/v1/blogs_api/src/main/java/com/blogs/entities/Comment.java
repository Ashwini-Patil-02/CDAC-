package com.blogs.entities;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.FetchType;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.ManyToOne;
import jakarta.persistence.Table;
import jakarta.persistence.UniqueConstraint;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.ToString;

@Entity
@Table(name = "comments",
uniqueConstraints = 
@UniqueConstraint(columnNames = {"commenter_id","post_id"}))
@NoArgsConstructor
@Getter
@Setter
@ToString(callSuper = true,of= {"commentText","rating"})
public class Comment extends BaseEntity {
	@Column(name = "comment_text", length = 100)
	private String commentText;
	private int rating;
	//Comment *-->1 BlogPost
	@ManyToOne(fetch = FetchType.LAZY)//def fetch type=EAGER
	@JoinColumn(name="post_id",nullable = false)
	private BlogPost post;
	//Comment *-->1 User(Commenter)
	@ManyToOne(fetch = FetchType.LAZY)
	@JoinColumn(name="commenter_id",nullable = false)
	private User commenter;
	
	
	public Comment(String commentText, int rating) {
		super();
		this.commentText = commentText;
		this.rating = rating;
	}

}
