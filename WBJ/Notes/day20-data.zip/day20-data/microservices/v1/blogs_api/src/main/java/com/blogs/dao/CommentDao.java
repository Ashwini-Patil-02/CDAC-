package com.blogs.dao;

import org.springframework.data.jpa.repository.JpaRepository;

import com.blogs.entities.Comment;

public interface CommentDao extends JpaRepository<Comment, Long> {

}
