package com.blogs.service;

import com.blogs.dto.CommentRequest;
import com.blogs.dto.CommentResp;

public interface CommentService {
	CommentResp postNewComment(CommentRequest dto);
}
