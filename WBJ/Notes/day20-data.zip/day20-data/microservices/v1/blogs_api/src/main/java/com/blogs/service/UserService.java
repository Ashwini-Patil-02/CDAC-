package com.blogs.service;

import com.blogs.dto.AuthRequest;
import com.blogs.dto.UserDTO;

public interface UserService {
//user signin
	UserDTO authenticateUser(AuthRequest dto);
//signup
	UserDTO registerUser(UserDTO request);
}
