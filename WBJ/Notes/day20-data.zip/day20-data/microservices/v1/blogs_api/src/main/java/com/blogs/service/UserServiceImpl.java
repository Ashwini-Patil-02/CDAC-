package com.blogs.service;

import org.modelmapper.ModelMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.blogs.custom_exceptions.AuthenticationException;
import com.blogs.dao.UserDao;
import com.blogs.dto.AuthRequest;
import com.blogs.dto.UserDTO;
import com.blogs.entities.User;

@Service
@Transactional
public class UserServiceImpl implements UserService {
	// depcy
	@Autowired
	private UserDao userDao;
	@Autowired
	private ModelMapper mapper;

	@Override
	public UserDTO authenticateUser(AuthRequest dto) {
		// 1.invoke dao 's method
		User user = userDao.findByEmailAndPassword(
				dto.getEmail(), dto.getPwd())
				.orElseThrow(() -> 
				new AuthenticationException("Invalid Email or Password !!!!!!"));
		//valid login -user : persistent -> entity -> dto
		return mapper.map(user, UserDTO.class);
	}

	@Override
	public UserDTO registerUser(UserDTO request) {
		User persistentEntity = userDao.save(mapper.map(request, User.class));
		return mapper.map(persistentEntity, UserDTO.class);
	}
	

}
