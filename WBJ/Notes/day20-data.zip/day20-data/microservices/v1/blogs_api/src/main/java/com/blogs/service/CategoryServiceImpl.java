package com.blogs.service;

import java.util.List;
import java.util.stream.Collectors;

import org.modelmapper.ModelMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.blogs.custom_exceptions.ResourceNotFoundException;
import com.blogs.dao.CategoryDao;
import com.blogs.dto.CategoryDTO;
import com.blogs.dto.CategoryPostDTO;
import com.blogs.entities.Category;

@Service // represents a spring bean containing B.L
@Transactional // for automatic tx management
public class CategoryServiceImpl implements CategoryService {
	// dependency - DAO
	@Autowired
	private CategoryDao categoryDao;
	// dependency - model mapper
	@Autowired
	private ModelMapper mapper;

	@Override
	public List<CategoryDTO> getCategories() {
		// TODO Auto-generated method stub
	
		return categoryDao.findAll().stream()
				.map(category -> mapper.map(category, CategoryDTO.class))
				.collect(Collectors.toList());
	}

	@Override
	public String addNewCategory(CategoryDTO dto) {
		Category savedCategory = categoryDao.save(mapper.map(dto, Category.class));
		// savedCatgory - PERSISTENT
		return "new category added with id=" + savedCategory.getId();
	}
	/*
	 * After @Transactional method rets - hibernate performs tx.commit() - in case
	 * of no run time exc. OR tx.rollback() - in case of run time exc.
	 */

	@Override
	public String deleteCategory(Long categoryId) {
		// invoke dao's inherited method
		if (categoryDao.existsById(categoryId)) {
			categoryDao.deleteById(categoryId);
			return "deleted category details";
		}
		throw new ResourceNotFoundException("Invalid Category ID !!!!");
	}

	@Override
	public CategoryDTO getCategory(Long categoryId) {
		// TODO Auto-generated method stub
		Category entity = categoryDao.findById(categoryId)
				.orElseThrow(() -> new ResourceNotFoundException("Invalid Category Id !!!!"));
		return mapper.map(entity, CategoryDTO.class);
	}

	@Override
	public String updateCategory(Long categoryId, Category category) {
		if (categoryDao.existsById(categoryId)) {
			// => valid id
			categoryDao.save(category);
			return "Updated category !";
		}
		throw new ResourceNotFoundException("Category doen't exist!!!!");
	}

	@Override
	public CategoryPostDTO getCategoryAndPosts(Long categoryId) {
		Category entity = categoryDao.getCategoryAndPostDetails(categoryId);
		return mapper.map(entity, CategoryPostDTO.class);
	}

}
