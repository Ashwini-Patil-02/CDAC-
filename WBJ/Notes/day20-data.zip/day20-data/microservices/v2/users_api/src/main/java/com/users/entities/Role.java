package com.users.entities;

public enum Role {
	ADMIN, BLOGGER, COMMENTER
}
