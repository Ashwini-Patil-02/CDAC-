package com.blogs.service;

import java.util.List;
import java.util.stream.Collectors;

import org.modelmapper.ModelMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.blogs.custom_exceptions.ResourceNotFoundException;
import com.blogs.dao.BlogPostDao;
import com.blogs.dao.CategoryDao;
import com.blogs.dto.ApiResponse;
import com.blogs.dto.BlogPostReqDTO;
import com.blogs.dto.BlogPostRespDTO;
import com.blogs.entities.BlogPost;
import com.blogs.entities.Category;

@Service
@Transactional
public class BlogPostServiceImpl implements BlogPostService {
	// depcy
	@Autowired
	private BlogPostDao blogPostDao;
	@Autowired
	private ModelMapper mapper;

	@Autowired
	private CategoryDao categoryDao;

	@Override
	public ApiResponse postNewBlog(BlogPostReqDTO requestDTO) {
		// 1. get category from it's id
		Category category = categoryDao.findById(requestDTO.getCategoryId())
				.orElseThrow(() -> new ResourceNotFoundException("Invalid category id !!!!"));
		//To Do - add a microservice call here - to validate if user id is valid or not !
		BlogPost blogPost = mapper.map(requestDTO, BlogPost.class);
		// 2. category 1<--->* post (establish bi dir asso)
		category.addBlogPost(blogPost);
		// 3. UserService (Blogger service) is another microservice
		blogPost.setBloggerId(requestDTO.getBloggerId());
		// 4. save blog post
		BlogPost periststentBlog = blogPostDao.save(blogPost);
		return new ApiResponse("New Blog added with ID=" + periststentBlog.getId());
	}

	@Override
	public List<BlogPostRespDTO> getPostByAuthor(Long bloggerId) {
		// TODO Auto-generated method stub
		return blogPostDao.findByBloggerId(bloggerId)
				.stream()
				.map(blog -> mapper.map(blog, BlogPostRespDTO.class))
				.collect(Collectors.toList());
	}

}
