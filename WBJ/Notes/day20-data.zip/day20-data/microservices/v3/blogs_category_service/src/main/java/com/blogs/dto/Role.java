package com.blogs.dto;

public enum Role {
	ADMIN, BLOGGER, COMMENTER
}
