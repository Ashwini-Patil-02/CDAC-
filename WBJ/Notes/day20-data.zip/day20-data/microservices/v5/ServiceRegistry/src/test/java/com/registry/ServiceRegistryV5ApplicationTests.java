package com.registry;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ServiceRegistryV5ApplicationTests {

	@Test
	void contextLoads() {
	}

}
