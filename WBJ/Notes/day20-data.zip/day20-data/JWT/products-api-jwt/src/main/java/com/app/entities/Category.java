package com.app.entities;

public enum Category {
	FOOD, CLOTHING, SHOES, PERFUMES
}
