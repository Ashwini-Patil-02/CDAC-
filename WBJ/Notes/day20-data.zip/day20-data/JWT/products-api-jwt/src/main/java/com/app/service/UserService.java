package com.app.service;

import com.app.dto.Signup;

public interface UserService {
	//add signup method
	Signup userRegistration(Signup reqDTO);
}
