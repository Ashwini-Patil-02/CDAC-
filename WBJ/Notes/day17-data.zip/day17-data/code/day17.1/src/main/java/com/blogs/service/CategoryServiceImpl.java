package com.blogs.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.blogs.custom_exceptions.ResourceNotFoundException;
import com.blogs.dao.CategoryDao;
import com.blogs.dto.ApiResponse;
import com.blogs.pojos.Category;

@Service
@Transactional //auto tx management
public class CategoryServiceImpl implements CategoryService {
	//depcy 
	@Autowired //byType
	private CategoryDao categoryDao;

	@Override
	public List<Category> getAllCategories() {
		// TODO Auto-generated method stub
		return categoryDao.findAll();
	}

	@Override
	public String addNewCategory(Category newCategory) {
		//invoke the inherited method
		Category persistentCategory = categoryDao.save(newCategory);
		return "Added new category with ID="+persistentCategory.getId();
	}

	@Override
	public ApiResponse deleteCategory(Long categoryId) {
		if(categoryDao.existsById(categoryId)) {
			//=> valid category id
			categoryDao.deleteById(categoryId);
			return new ApiResponse("Deleted category details !");
		}
		throw new ResourceNotFoundException("Invalid Category ID !!!!!");
	}

	@Override
	public Category getCategoryDetails(Long categoryId) {
		// TODO Auto-generated method stub
		return categoryDao.findById(categoryId)
				.orElseThrow(() -> new ResourceNotFoundException("Invalid Category ID!!!!"));
	}

	@Override
	public ApiResponse updateCategoryDetails(Long categoryId, Category category) {
		// 1. validate if category exists
		if(categoryDao.existsById(categoryId)) {
			// => category exists
			//category - DETACHED
			Category category2 = categoryDao.save(category);//upon commit -> update
			//category2 - PERSISTENT
			return new ApiResponse("Updated Category Details !!!");
			
		}
		return new ApiResponse("Invalid Category ID!!!");
	}// @TX method rets --> Tx mgr bean chks for RunTimeExc-> in case of no exc -> tx.commit
	// -> DML - update
	
	
	
	

}
