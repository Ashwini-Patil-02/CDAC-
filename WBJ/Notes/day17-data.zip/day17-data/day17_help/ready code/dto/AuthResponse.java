package com.blogs.dto;

import java.time.LocalDate;

import com.blogs.entities.UserRole;

import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;


@Getter
@Setter

public class AuthResponse extends BaseDTO {

	private String firstName;
	private String lastName;
	private String email;
	private LocalDate dob;
	private double regAmount;
	private UserRole role;

}
