package com.blogs.dto;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.ToString;

@NoArgsConstructor
@Getter
@Setter
@ToString(callSuper = true)
@AllArgsConstructor
public class AddBlogPostDTO extends BaseDTO {
	private Long bloggerId;
	private Long categoryId;
	private String title;
	private String description;
	private String content;
}
