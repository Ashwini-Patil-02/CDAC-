package com.blogs.service;

import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;

import com.blogs.dto.ApiResponse;
import com.blogs.dto.BlogPostDTO;

@SpringBootTest
class TestBlogPostServiceImpl {
	@Autowired
	private BlogPostService blogPostService;

	@Test
	void testAddNewBlogPost() {
		BlogPostDTO dto=new BlogPostDTO(7l, 3l, "title-77", "desc-77", "some contents !!");
		ApiResponse resp = blogPostService.addNewBlogPost(dto);
		assertEquals(true, resp.getMessage().contains("Added"));
		
	}

}
