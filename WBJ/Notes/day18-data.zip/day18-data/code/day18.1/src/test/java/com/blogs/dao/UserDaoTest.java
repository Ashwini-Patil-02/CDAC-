package com.blogs.dao;

import static org.junit.jupiter.api.Assertions.*;

import java.util.Optional;

import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.jdbc.AutoConfigureTestDatabase;
import org.springframework.boot.test.autoconfigure.jdbc.AutoConfigureTestDatabase.Replace;
import org.springframework.boot.test.autoconfigure.orm.jpa.DataJpaTest;

import com.blogs.entities.User;
@DataJpaTest //mandatory Spring boot annotation to indicate a DAO layer test class
@AutoConfigureTestDatabase(replace = Replace.NONE)//DO NOT replace main DB (mysql)
class UserDaoTest {
	@Autowired
	private UserDao userDao;

	@Test //JUnit method level annotation
	void testFindByEmailAndPassword() {
//		Optional<User> optional = userDao.findByEmailAndPassword("a2@gmail.com", "2345");
//		//1st arg - expected , 2nd - actual
//		assertEquals(false, optional.isEmpty());
		User user=userDao.findByEmailAndPassword("a2@gmail.com", "2345").orElseThrow();
	//	assertNotNull(user);
		assertEquals(1500, user.getRegAmount());
	}

}
