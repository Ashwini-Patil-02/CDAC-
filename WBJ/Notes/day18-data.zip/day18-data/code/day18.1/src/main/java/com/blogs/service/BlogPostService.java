package com.blogs.service;

import com.blogs.dto.ApiResponse;
import com.blogs.dto.BlogPostDTO;

public interface BlogPostService {
//add a method to create new blog post
	ApiResponse addNewBlogPost(BlogPostDTO dto);
}
