package com.blogs.dto;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

//(category Id , author id , title content , desc)
@Getter
@Setter
@ToString
@AllArgsConstructor
public class BlogPostDTO {
	private Long categoryId;
	private Long bloggerId;
	private String title;
	private String description;
	private String content;
}
