package com.blogs.entities;

public enum UserRole {
	ADMIN, BLOGGER
}
