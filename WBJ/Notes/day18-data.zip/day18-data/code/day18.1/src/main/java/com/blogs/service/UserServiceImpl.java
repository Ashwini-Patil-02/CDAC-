package com.blogs.service;

import java.util.Optional;

import org.modelmapper.ModelMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.blogs.custom_exceptions.ResourceNotFoundException;
import com.blogs.dao.UserDao;
import com.blogs.dto.AuthRequest;
import com.blogs.dto.UserRespDTO;
import com.blogs.entities.User;

@Service
@Transactional
public class UserServiceImpl implements UserService {
	//depcy - dao layer i/f
	@Autowired
	private UserDao userDao;
	//depcy - model mapper
	@Autowired
	private ModelMapper mapper;

	@Override
	public UserRespDTO authenticate(AuthRequest dto) {
		// invoke dao's method
		Optional<User> optional = userDao.
				findByEmailAndPassword(dto.getEmail(), dto.getPassword());
		//extract user froUserRespDTOm optional , o.w throw exc
		User userEntity=optional
				.orElseThrow(() -> new ResourceNotFoundException("Invalid email or password !!!!"));
		//entity -> dto 
		return mapper.map(userEntity, UserRespDTO.class);
	}

}
