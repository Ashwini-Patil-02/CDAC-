package com.blogs.service;

import java.util.List;

import com.blogs.dto.ApiResponse;
import com.blogs.dto.CategoryRespDTO;
import com.blogs.entities.Category;

public interface CategoryService {
//add a method to get all categories
	List<CategoryRespDTO> getAllCategories();
	//add a method to save new category details
	String addNewCategory(Category newCategory);
	ApiResponse deleteCategory(Long categoryId);
	//add a method to get category details by id
	CategoryRespDTO getCategoryDetails(Long categoryId);
	ApiResponse updateCategoryDetails(Long categoryId, Category category);
	
}
