package com.blogs.service;

import org.modelmapper.ModelMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.blogs.custom_exceptions.ResourceNotFoundException;
import com.blogs.dao.BlogPostDao;
import com.blogs.dao.CategoryDao;
import com.blogs.dao.UserDao;
import com.blogs.dto.ApiResponse;
import com.blogs.dto.BlogPostDTO;
import com.blogs.entities.BlogPost;
import com.blogs.entities.Category;
import com.blogs.entities.User;

@Service
@Transactional
public class BlogPostServiceImpl implements BlogPostService {
	//depcy 
	@Autowired
	private BlogPostDao blogPostDao;
	
	@Autowired
	private CategoryDao categoryDao;
	
	@Autowired
	private UserDao userDao;
	
	@Autowired
	private ModelMapper modelMapper;

	@Override
	public ApiResponse addNewBlogPost(BlogPostDTO dto) {
		System.out.println("in add new post "+dto);
		// 1. validate if category valid
		Category category=categoryDao.findById(dto.getCategoryId())
				.orElseThrow(() -> new ResourceNotFoundException("Invalid Category ID !!!"));
		//category : PERSISTENT
		//2.  validate if blogger id is  valid
		User blogger=userDao.findById(dto.getBloggerId())
				.orElseThrow(() -> new ResourceNotFoundException("Invalid Blogger ID !!!"));
		//blogger : PERSISTENT
		//3. dto -> entity
		BlogPost blogPostEntity = modelMapper.map(dto, BlogPost.class);
		//4. establish a bi dir association Category 1 <----> * BlogPost
		category.addBlogPost(blogPostEntity);
		//5. establish uni dir association BlogPost *--->1 User(blogger)
		blogPostEntity.setBlogger(blogger);
		//6. set available true
		blogPostEntity.setAvailable(true);
		//. save blog post
	//	blogPostDao.save(blogPostEntity); : NOT needed : since using cascadeType.ALL
		
		return new ApiResponse("Added new blog post !");
	}

}
