package com.blogs.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.blogs.dto.ApiResponse;
import com.blogs.dto.AuthRequest;
import com.blogs.dto.UserRespDTO;
import com.blogs.service.UserService;

import jakarta.validation.Valid;

@RestController
@RequestMapping("/users")
@CrossOrigin(origins = "http://localhost:3000")
public class UserController {
	// depcy - service layer i/f
	@Autowired // byType
	private UserService userService;

	public UserController() {
		System.out.println("in ctor : " + getClass());
	}

	/*
	 * Desc - User signin URL - http://host:port/users/signin Method - POST payload
	 * - dto (email n pwd) Successful Resp - SC 200, user details - all (dto)
	 * excluding password, image , adhaar card , languages… Error resp - SC
	 * 401(authentication failed !) , error mesg -wrapped in DTO(ApiResponse)
	 */
	@PostMapping("/signin")
	public ResponseEntity<?> authenticateUser(@RequestBody @Valid AuthRequest dto) {
		System.out.println("in user auth " + dto);

		// invoke service method
		UserRespDTO respDTO = userService.authenticate(dto);
		return ResponseEntity.ok(respDTO);

	}

}
