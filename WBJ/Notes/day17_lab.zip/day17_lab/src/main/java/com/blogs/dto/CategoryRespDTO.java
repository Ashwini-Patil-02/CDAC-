package com.blogs.dto;

import lombok.Getter;
import lombok.Setter;

//id , cr tm , update tm , name ,desc
@Getter
@Setter
public class CategoryRespDTO extends BaseDTO {
	private String categoryName;
	private String description;
}
