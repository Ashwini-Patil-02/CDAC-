package com.blogs.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.blogs.dto.ApiResponse;
import com.blogs.entities.Category;
import com.blogs.service.CategoryService;

@RestController // @Controller+@ResponseBody
//singleton n eager spring bean - meant for req handling purpose 
@RequestMapping("/categories")
public class CategoryController {
	// depcy - service i/f
	@Autowired
	private CategoryService categoryService;

	public CategoryController() {
		System.out.println("in ctor " + getClass());
	}

	/*
	 * URL - http://host:port/categories Method - GET Payload - None Resp -
	 * ResponseEntity - @ResponseBody List<Category> --> D.S --> Jackson(HTTP
	 * converter) : java->json serialization | marshalling --> sent to REST client
	 * (postman|swagger) Desc - get all categories
	 */
	@GetMapping
	public ResponseEntity<?> getCategories() {
		System.out.println("in get all categories");
		List<Category> categories = categoryService.getAllCategories();
		if (categories.isEmpty())
			return ResponseEntity.status(HttpStatus.NO_CONTENT).build();
		return ResponseEntity.status(HttpStatus.OK).body(categories);
	}

	/*
	 * URL - http://host:port/categories Method - POST Payload - JSON representation
	 * of Category Annotation for de-serialization(un marshalling) -Json -> Java
	 * : @RequestBody Resp - @ResponseBody message Desc - add new category
	 */
	@PostMapping
	public ResponseEntity<?> addNewCategory(@RequestBody Category category) {
		System.out.println("in add new category " + category);
		return ResponseEntity.status(HttpStatus.CREATED) // SC 201
				.body(new ApiResponse(categoryService.addNewCategory(category)));
	}

	/*
	 * URL - http://host:port/categories/{categoryId} Method - DELETE Payload - Path
	 * Variable Resp - ResponseEntity - ApiResponse DTO (mesg + timestamp) Desc -
	 * delete a category
	 */
	@DeleteMapping("/{categoryId}")
	public ResponseEntity<?> deleteCategoryDetails(@PathVariable Long categoryId) {
		System.out.println("in delete category " + categoryId);
		try {
			return ResponseEntity.ok(categoryService.deleteCategory(categoryId));
		} catch (RuntimeException e) {
			return ResponseEntity.status(HttpStatus.NOT_FOUND).body(new ApiResponse(e.getMessage()));
		}
	}

	/*
	 * URL - http://host:port/categories/{categoryId} 
	 * Method - GET 
	 * Payload - PathVariable 
	 * Resp - ResponseEntity - Category - entity 
	 * Desc - get a category by  it's id
	 */
	@GetMapping("/{catId}")
	public ResponseEntity<?> getCategoryDetails(@PathVariable Long catId) {
		System.out.println("in get category dtls " + catId);
		try {
			return ResponseEntity.ok(categoryService.getCategoryDetails(catId));
		} catch (RuntimeException e) {
			return ResponseEntity.status(HttpStatus.NOT_FOUND).body(
					new ApiResponse(e.getMessage()));
		}
	}
	/*
	 * URL - http://host:port/categories/{categoryId} 
	 * Method - PUT 
	 * Payload - PathVariable - categogory ID + request body (category details)
	 * Resp - ResponseEntity -mesg wrapped in DTO
	 * Desc -update complete category details (name n desc)
	 */
	@PutMapping("/{categoryId}")
	public ResponseEntity<?> updateCategoryDetails(@PathVariable Long categoryId,
		@RequestBody Category category)
	{
		System.out.println("in update category "+categoryId+" "+category);
		try {
			return ResponseEntity.ok(
					categoryService.updateCategoryDetails(categoryId,category));
		} catch (RuntimeException e) {
			return ResponseEntity.status(HttpStatus.NOT_FOUND).body(
					new ApiResponse(e.getMessage()));
		}
	}

}
