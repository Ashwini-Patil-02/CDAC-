package com.cdac.dao;

import com.cdac.pojos.Voter;
import com.cdac.utils.DBUtils;

import java.sql.*;
import java.util.ArrayList;
import java.util.List;

public class VoterDao {
    // Add a new voter
    public void addVoter(String name, int age, String gender, String constituency) throws SQLException {
        String query = "INSERT INTO voters (name, age, gender, constituency) VALUES (?, ?, ?, ?)";  // Correct table name: voters
        try (Connection conn = DBUtils.getConnection(); PreparedStatement stmt = conn.prepareStatement(query)) {
            stmt.setString(1, name);
            stmt.setInt(2, age);
            stmt.setString(3, gender);
            stmt.setString(4, constituency);
            stmt.executeUpdate();
        }
    }

    // Get all voters
    public List<Voter> getAllVoters() throws SQLException {
        String query = "SELECT * FROM voters";  // Correct table name: voters
        List<Voter> voters = new ArrayList<>();
        try (Connection conn = DBUtils.getConnection(); Statement stmt = conn.createStatement(); ResultSet rs = stmt.executeQuery(query)) {
            while (rs.next()) {
                voters.add(new Voter(
                    rs.getInt("id"),
                    rs.getString("name"),
                    rs.getInt("age"),
                    rs.getString("gender"),
                    rs.getString("constituency")
                ));
            }
        }
        return voters;
    }

    // Update a voter
    public void updateVoter(int id, String name, int age, String gender, String constituency) throws SQLException {
        String query = "UPDATE voters SET name=?, age=?, gender=?, constituency=? WHERE id=?";  // Correct table name: voters
        try (Connection conn = DBUtils.getConnection(); PreparedStatement stmt = conn.prepareStatement(query)) {
            stmt.setString(1, name);
            stmt.setInt(2, age);
            stmt.setString(3, gender);
            stmt.setString(4, constituency);
            stmt.setInt(5, id);
            stmt.executeUpdate();
        }
    }

    // Delete a voter
    public void deleteVoter(int id) throws SQLException {
        String query = "DELETE FROM voters WHERE id=?";  // Correct table name: voters
        try (Connection conn = DBUtils.getConnection(); PreparedStatement stmt = conn.prepareStatement(query)) {
            stmt.setInt(1, id);
            stmt.executeUpdate();
        }
    }
}
