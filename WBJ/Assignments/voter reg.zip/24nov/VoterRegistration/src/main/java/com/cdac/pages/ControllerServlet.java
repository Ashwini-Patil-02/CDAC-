package com.cdac.pages;

import com.cdac.dao.VoterDao;
import com.cdac.pojos.Voter;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.util.List;

public class ControllerServlet extends HttpServlet {
    private VoterDao voterDao = new VoterDao();

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        String action = request.getParameter("action");

        try {
            if ("add".equals(action)) {
                // Add a voter
                String name = request.getParameter("name");
                int age = Integer.parseInt(request.getParameter("age"));
                String gender = request.getParameter("gender");
                String constituency = request.getParameter("constituency");
                voterDao.addVoter(name, age, gender, constituency);

                // After adding, forward to viewVoters.jsp to display the updated list
                loadVoters(request, response);
                
            } else if ("update".equals(action)) {
                // Update a voter
                int id = Integer.parseInt(request.getParameter("id"));
                String name = request.getParameter("name");
                int age = Integer.parseInt(request.getParameter("age"));
                String gender = request.getParameter("gender");
                String constituency = request.getParameter("constituency");
                voterDao.updateVoter(id, name, age, gender, constituency);

                // After updating, forward to viewVoters.jsp to display the updated list
                loadVoters(request, response);

            } else if ("delete".equals(action)) {
                // Delete a voter
                int id = Integer.parseInt(request.getParameter("id"));
                voterDao.deleteVoter(id);

                // After deleting, forward to viewVoters.jsp to display the updated list
                loadVoters(request, response);
            }
        } catch (Exception e) {
            // Logging exception or showing error page
            e.printStackTrace();
            request.setAttribute("error", "An error occurred while processing your request.");
            request.getRequestDispatcher("error.jsp").forward(request, response);
        }
    }

    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        loadVoters(request, response);
    }

    private void loadVoters(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        try {
            // Retrieve the list of voters from the database
            List<Voter> voters = voterDao.getAllVoters();
            
            // Set the voters list as a request attribute
            request.setAttribute("voters", voters);
            
            // Forward the request to the viewVoters.jsp page
            request.getRequestDispatcher("viewVoters.jsp").forward(request, response);
        } catch (Exception e) {
            // Handle any exception (e.g., DB errors)
            e.printStackTrace();
            request.setAttribute("error", "Error fetching voter data.");
            request.getRequestDispatcher("error.jsp").forward(request, response);
        }
    }
}
